from django.urls import path
from . import views

app_name = "tarefas"
urlpatterns = [
    path("", views.lista_tarefas, name="lista"),
    path("<int:tarefa_id>/concluir/", views.concluir_tarefa, name="concluir"),
    path("<int:tarefa_id>/deletar/", views.deletar_tarefa, name="deletar"),
    path('<int:tarefa_id>/editar/', views.editar_tarefa, name='editar'),
]