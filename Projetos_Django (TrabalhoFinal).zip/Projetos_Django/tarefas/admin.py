from django.contrib import admin
from .models import Tarefa

class TarefaAdmin(admin.ModelAdmin):
    list_display = ["titulo", "concluido", "criado_em"]
    list_filter = ["concluido", "criado_em"]
    search_fields = ["titulo"]


admin.site.register(Tarefa, TarefaAdmin)