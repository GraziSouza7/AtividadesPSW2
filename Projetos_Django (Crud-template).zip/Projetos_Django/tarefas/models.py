from django.db import models

class Tarefa(models.Model):
    titulo = models.CharField(max_length=200)
    descricao = models.TextField(blank=True, null=True) # Opcional, o usuário preenche se quiser
    concluido = models.BooleanField(default=False) # Começa como Falso (não concluída)
    criado_em = models.DateTimeField(auto_now_add=True) # Salva a data atual automaticamente

    def __str__(self):
        return self.titulo