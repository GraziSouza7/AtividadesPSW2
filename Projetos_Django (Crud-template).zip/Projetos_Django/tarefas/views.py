from django.shortcuts import render, redirect, get_object_or_404
from .models import Tarefa

def lista_tarefas(request):
    # Se o usuário clicou no botão "Adicionar"
    if request.method == "POST":
        texto_da_tarefa = request.POST.get("titulo")
        if texto_da_tarefa:
            Tarefa.objects.create(titulo=texto_da_tarefa) 
        return redirect("tarefas:lista")

    # Se o usuário está apenas entrando na página
    todas_tarefas = Tarefa.objects.all()
    return render(request, "tarefas/lista.html", {"tarefas": todas_tarefas})

def concluir_tarefa(request, tarefa_id):
    tarefa = get_object_or_404(Tarefa, id=tarefa_id)
    tarefa.concluido = True  # Marca a tarefa como feita
    tarefa.save()            # Salva no banco
    return redirect("tarefas:lista")

# ADICIONANDO A FUNÇÃO DE DELETAR QUE ESTAVA FALTANDO:
def deletar_tarefa(request, tarefa_id):
    tarefa = get_object_or_404(Tarefa, id=tarefa_id)
    tarefa.delete()          # Deleta a tarefa do banco de dados
    return redirect("tarefas:lista")




    # Adicione esta função no final do seu tarefas/views.py
def editar_tarefa(request, tarefa_id):
    tarefa = get_object_or_404(Tarefa, id=tarefa_id)
    
    if request.method == "POST":
        novo_titulo = request.POST.get("titulo")
        if novo_titulo:
            tarefa.titulo = novo_titulo
            tarefa.save() # Salva o novo nome no banco
            return redirect("tarefas:lista")
            
    return render(request, "tarefas/editar.html", {"tarefa": tarefa})