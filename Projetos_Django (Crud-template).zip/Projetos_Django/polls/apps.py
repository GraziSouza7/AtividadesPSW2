from django.apps import AppConfig

class PollsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'polls'
    
    # Adicione esta linha para mudar o título no admin:
    verbose_name = 'Gerenciador de Enquetes'