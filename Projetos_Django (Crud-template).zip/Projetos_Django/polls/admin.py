from django.contrib import admin
from .models import Choice, Question

# Títulos principais do topo do painel Admin (Modificados corretamente)
admin.site.site_header = "Administração das Enquetes"
admin.site.site_title = "Admin Enquetes"
admin.site.index_title = "Bem-vindo ao Gerenciador de Enquetes"

class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 3

class QuestionAdmin(admin.ModelAdmin):
    fieldsets = [
        (None, {"fields": ["question_text"]}),
        ("Informações de Data", {"fields": ["pub_date"], "classes": ["collapse"]}), # Traduzido aqui!
    ]
    inlines = [ChoiceInline]
    
    # MELHORIAS DA PARTE 7:
    list_display = ["question_text", "pub_date", "was_published_recently"] # Colunas da tabela
    list_filter = ["pub_date"] # Barra de filtros na lateral direita
    search_fields = ["question_text"] # Campo de busca no topo

admin.site.register(Question, QuestionAdmin)